import { useEffect, useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { AndroidEmulator } from './components/AndroidEmulator';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { WorkbenchPanels, WorkbenchTab } from './components/WorkbenchPanels';
import { generateAndroidProjectFiles } from './data/androidSourceCode';
import {
  BUSINESS_DOMAINS,
  BusinessDomainId,
  runLocalSimulation,
  SampleRecord,
  ScreenId,
  SimulationInputs,
  SimulationResult,
} from './data/domains';
import { usePWAInstall } from './hooks/usePWAInstall';
import { createZipBlob } from './utils/zipBuilder';

function buildInitialInputs(domainId: BusinessDomainId): SimulationInputs {
  const first = BUSINESS_DOMAINS[domainId].records[0];
  return {
    selectedRecordId: first.id,
    itemName: first.name,
    paramA: first.paramA,
    paramB: first.paramB,
    paramC: first.paramC,
    paramD: first.paramD,
    scenario: 'baseline',
  };
}

export default function App() {
  const [domainId, setDomainId] = useState<BusinessDomainId>('retail');
  const [appName, setAppName] = useState<string>(BUSINESS_DOMAINS.retail.defaultAppName);
  const [activeScreen, setActiveScreen] = useState<ScreenId>('welcome');
  const [activeTab, setActiveTab] = useState<WorkbenchTab>('emulator');
  const [showMobileDrawer, setShowMobileDrawer] = useState(false);
  const [isMobileViewport, setIsMobileViewport] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth < 1024 : false
  );

  const { isInstalled } = usePWAInstall();

  useEffect(() => {
    const onResize = () => setIsMobileViewport(window.innerWidth < 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const domain = BUSINESS_DOMAINS[domainId];

  const [userName, setUserName] = useState<string>(domain.samplePersonaName);
  const [userRole, setUserRole] = useState<string>(domain.samplePersonaRole);
  const [inputs, setInputs] = useState<SimulationInputs>(() => buildInitialInputs('retail'));

  const [history, setHistory] = useState<SimulationResult[]>(() => [
    runLocalSimulation('retail', buildInitialInputs('retail')),
  ]);
  const [selectedReportId, setSelectedReportId] = useState<string>('');

  const androidFiles = useMemo(
    () => generateAndroidProjectFiles(domainId, appName),
    [domainId, appName]
  );

  const handleSelectDomain = (nextId: BusinessDomainId) => {
    const nextDomain = BUSINESS_DOMAINS[nextId];
    const initialInputs = buildInitialInputs(nextId);
    const initialResult = runLocalSimulation(nextId, initialInputs);

    setDomainId(nextId);
    setAppName(nextDomain.defaultAppName);
    setUserName(nextDomain.samplePersonaName);
    setUserRole(nextDomain.samplePersonaRole);
    setInputs(initialInputs);
    setHistory([initialResult]);
    setSelectedReportId(initialResult.id);
  };

  const handleSelectRecord = (record: SampleRecord, navigateToFunction = false) => {
    setInputs((prev) => ({
      ...prev,
      selectedRecordId: record.id,
      itemName: record.name,
      paramA: record.paramA,
      paramB: record.paramB,
      paramC: record.paramC,
      paramD: record.paramD,
    }));
    if (navigateToFunction) {
      setActiveScreen('function');
    }
  };

  const handleRunSimulation = () => {
    const result = runLocalSimulation(domainId, inputs);
    setHistory((prev) => [result, ...prev.slice(0, 7)]);
    setSelectedReportId(result.id);
    setActiveScreen('reports');
  };

  const handleDownloadZip = () => {
    const slug = (appName.trim() || domain.defaultAppName)
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '');
    const entries = androidFiles.map((f) => ({
      path: `${slug || 'bizpulse'}-android/${f.zipPath}`,
      content: f.content,
    }));
    const blob = createZipBlob(entries);
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${slug || 'bizpulse'}-android-prototype.zip`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  };

  const navItems: { id: WorkbenchTab; label: string }[] = [
    { id: 'emulator', label: 'App Flow' },
    { id: 'code', label: 'Kotlin Source' },
    { id: 'architecture', label: 'Architecture' },
    { id: 'guide', label: 'APK & Demo' },
  ];

  // When running as an installed standalone app OR on a mobile viewport,
  // render the pure native full-screen 4-screen mobile app directly (no website chrome).
  if (isInstalled || isMobileViewport) {
    return (
      <>
        <AndroidEmulator
          mode="native"
          domain={domain}
          domainId={domainId}
          onSelectDomain={handleSelectDomain}
          appName={appName}
          activeScreen={activeScreen}
          onNavigate={setActiveScreen}
          userName={userName}
          onChangeUserName={setUserName}
          userRole={userRole}
          onChangeUserRole={setUserRole}
          inputs={inputs}
          onChangeInputs={setInputs}
          onSelectRecord={handleSelectRecord}
          onRunSimulation={handleRunSimulation}
          history={history}
          selectedReportId={selectedReportId}
          onSelectReportId={setSelectedReportId}
          onOpenProjectDrawer={() => setShowMobileDrawer(true)}
          onDownloadAndroidProject={handleDownloadZip}
        />
        <OfflineIndicator />

        {showMobileDrawer && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex flex-col bg-slate-50"
          >
            <div className="flex h-14 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4">
              <span className="font-display text-sm font-semibold text-slate-900">
                Android Studio Source &amp; APK Guide
              </span>
              <button
                type="button"
                aria-label="Close source drawer"
                onClick={() => setShowMobileDrawer(false)}
                className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex gap-3 overflow-x-auto border-b border-slate-200 bg-white px-4 py-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1 text-xs font-medium whitespace-nowrap ${
                    activeTab === item.id
                      ? 'text-teal-700 underline underline-offset-4'
                      : 'text-slate-600'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <WorkbenchPanels
                activeTab={activeTab}
                domainId={domainId}
                onSelectDomain={handleSelectDomain}
                appName={appName}
                onChangeAppName={setAppName}
                domain={domain}
                activeScreen={activeScreen}
                onNavigateScreen={(scr) => {
                  setActiveScreen(scr);
                  setShowMobileDrawer(false);
                }}
                userName={userName}
                inputs={inputs}
                history={history}
                androidFiles={androidFiles}
                onDownloadZip={handleDownloadZip}
              />
            </div>
          </div>
        )}
      </>
    );
  }

  // Desktop Browser Workbench View (1024px+): Installable PWA + Mobile Preview + Kotlin/APK Export
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Three-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-3.5">
          {/* Zone 1: Single-element Brand wordmark */}
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('emulator');
            }}
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            {appName}
          </a>

          {/* Zone 2: 4 concise single-line nav links */}
          <nav aria-label="Workbench sections" className="flex items-center gap-7">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`border-b-2 py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-teal-700 text-slate-900'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Install App CTA */}
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton
              appName={appName}
              onDownloadAndroidProject={handleDownloadZip}
            />
          </div>
        </div>
      </header>

      {/* Main 12-Column Workbench */}
      <main id="top" className="mx-auto max-w-7xl px-6 py-8">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-teal-700">
              Installable Mobile App (PWA) · {domain.domainTitle}
            </p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-900">
              {appName} — {domain.tagline}
            </h1>
          </div>
          <button
            type="button"
            onClick={handleDownloadZip}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
          >
            Export Kotlin Project (.zip)
          </button>
        </div>

        <div className="grid grid-cols-12 items-start gap-8">
          {/* Left Column: Interactive Mobile App Viewport */}
          <div className="sticky top-24 col-span-5">
            <AndroidEmulator
              mode="framed"
              domain={domain}
              domainId={domainId}
              onSelectDomain={handleSelectDomain}
              appName={appName}
              activeScreen={activeScreen}
              onNavigate={setActiveScreen}
              userName={userName}
              onChangeUserName={setUserName}
              userRole={userRole}
              onChangeUserRole={setUserRole}
              inputs={inputs}
              onChangeInputs={setInputs}
              onSelectRecord={handleSelectRecord}
              onRunSimulation={handleRunSimulation}
              history={history}
              selectedReportId={selectedReportId}
              onSelectReportId={setSelectedReportId}
            />
          </div>

          {/* Right Column: Engineering Workbench & APK Packaging Tools */}
          <div className="col-span-7">
            <WorkbenchPanels
              activeTab={activeTab}
              domainId={domainId}
              onSelectDomain={handleSelectDomain}
              appName={appName}
              onChangeAppName={setAppName}
              domain={domain}
              activeScreen={activeScreen}
              onNavigateScreen={setActiveScreen}
              userName={userName}
              inputs={inputs}
              history={history}
              androidFiles={androidFiles}
              onDownloadZip={handleDownloadZip}
            />
          </div>
        </div>
      </main>

      <OfflineIndicator />
    </div>
  );
}
