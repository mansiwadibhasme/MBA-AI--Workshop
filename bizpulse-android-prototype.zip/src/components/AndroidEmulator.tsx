import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BarChart3,
  BatteryFull,
  Check,
  CheckCircle2,
  ClipboardCopy,
  Info,
  LayoutDashboard,
  LogOut,
  Minus,
  Plus,
  RotateCcw,
  Signal,
  SlidersHorizontal,
  Wifi,
} from 'lucide-react';
import {
  BUSINESS_DOMAINS,
  BusinessDomainId,
  DomainConfig,
  SampleRecord,
  ScreenId,
  SimulationInputs,
  SimulationResult,
} from '../data/domains';
import { PWAInstallButton } from './PWAInstallButton';

interface AndroidEmulatorProps {
  mode?: 'framed' | 'native';
  domain: DomainConfig;
  domainId: BusinessDomainId;
  onSelectDomain?: (id: BusinessDomainId) => void;
  appName: string;
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  userName: string;
  onChangeUserName: (name: string) => void;
  userRole: string;
  onChangeUserRole: (role: string) => void;
  inputs: SimulationInputs;
  onChangeInputs: (inputs: SimulationInputs) => void;
  onSelectRecord: (record: SampleRecord, navigateToFunction?: boolean) => void;
  onRunSimulation: () => void;
  history: SimulationResult[];
  selectedReportId: string;
  onSelectReportId: (id: string) => void;
  onOpenProjectDrawer?: () => void;
  onDownloadAndroidProject?: () => void;
}

export const AndroidEmulator: React.FC<AndroidEmulatorProps> = ({
  mode = 'framed',
  domain,
  domainId,
  onSelectDomain,
  appName,
  activeScreen,
  onNavigate,
  userName,
  onChangeUserName,
  userRole,
  onChangeUserRole,
  inputs,
  onChangeInputs,
  onSelectRecord,
  onRunSimulation,
  history,
  selectedReportId,
  onSelectReportId,
  onOpenProjectDrawer,
  onDownloadAndroidProject,
}) => {
  const [emblemError, setEmblemError] = useState(false);
  const [avatarError, setAvatarError] = useState(false);
  const [copiedReport, setCopiedReport] = useState(false);
  const [nameInput, setNameInput] = useState(userName);

  const isNative = mode === 'native';

  const activeReport =
    history.find((item) => item.id === selectedReportId) || history[0] || null;

  const handleCopyReport = () => {
    if (!activeReport) return;
    const text = [
      `${appName} (${domain.domainTitle}) - ${activeReport.sampleDisclaimer}`,
      `Item: ${activeReport.itemName}`,
      `Scenario: ${activeReport.scenarioLabel}`,
      `${activeReport.headlineLabel}: ${activeReport.headlineValue}`,
      `Status: ${activeReport.riskLabel}`,
      ...activeReport.secondaryMetrics.map((m) => `- ${m.label}: ${m.value}`),
      `Recommendations:`,
      ...activeReport.recommendations.map((r, i) => `${i + 1}. ${r.title} (${r.impact})`),
    ].join('\n');
    navigator.clipboard?.writeText(text);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 1800);
  };

  const handleStepParam = (
    key: 'paramA' | 'paramB' | 'paramC' | 'paramD',
    delta: number,
    min: number,
    max: number
  ) => {
    const next = Math.min(max, Math.max(min, inputs[key] + delta));
    onChangeInputs({ ...inputs, [key]: next });
  };

  const renderToneBadgeText = (tone: 'critical' | 'watch' | 'healthy', text: string) => {
    if (tone === 'critical') {
      return (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-rose-700">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span>{text}</span>
        </span>
      );
    }
    if (tone === 'watch') {
      return (
        <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
          <Info className="h-3.5 w-3.5 shrink-0" />
          <span>{text}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700">
        <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
        <span>{text}</span>
      </span>
    );
  };

  const maxTrend = Math.max(...domain.trendPoints.map((p) => p.value), 1);

  const shellClass = isNative
    ? 'flex min-h-dvh w-full flex-col bg-slate-50 text-slate-900'
    : 'mx-auto w-full max-w-[392px] rounded-[40px] border-[7px] border-slate-900 bg-slate-900 shadow-2xl shadow-slate-900/15';

  const innerClass = isNative
    ? 'flex min-h-dvh flex-1 flex-col bg-slate-50 text-slate-900'
    : 'flex h-[760px] flex-col overflow-hidden rounded-[33px] bg-slate-50 text-slate-900';

  return (
    <div className={shellClass}>
      <div className={innerClass}>
        {/* Simulated Android Status Bar (only in framed desktop preview) */}
        {!isNative && (
          <div className="flex h-8 shrink-0 items-center justify-between bg-white px-6 text-[11px] font-medium text-slate-700">
            <span className="tabular-nums">11:42</span>
            <div className="h-3.5 w-16 rounded-full bg-slate-900" aria-hidden="true" />
            <div className="flex items-center gap-1.5 text-slate-700">
              <Signal className="h-3 w-3" />
              <Wifi className="h-3 w-3" />
              <BatteryFull className="h-3.5 w-3.5" />
            </div>
          </div>
        )}

        {/* Native / Mobile Top Bar on Welcome Screen (for quick Install & Domain Switch) */}
        {isNative && activeScreen === 'welcome' && (
          <header className="sticky top-0 z-30 flex h-14 shrink-0 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md">
            <span className="font-display text-base font-bold tracking-tight text-slate-900">
              {appName}
            </span>
            <div className="flex items-center gap-2">
              {onOpenProjectDrawer && (
                <button
                  type="button"
                  onClick={onOpenProjectDrawer}
                  className="min-h-[40px] rounded-xl border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  Source &amp; APK
                </button>
              )}
              <PWAInstallButton
                compact
                appName={appName}
                onDownloadAndroidProject={onDownloadAndroidProject}
              />
            </div>
          </header>
        )}

        {/* Material 3 Top App Bar (Screens 2, 3, 4) */}
        {activeScreen !== 'welcome' && (
          <header
            className={`${
              isNative ? 'sticky top-0 z-30' : ''
            } flex h-14 shrink-0 items-center justify-between border-b border-slate-200 bg-white/95 px-3 backdrop-blur-md`}
          >
            <div className="flex min-w-0 items-center gap-1">
              {activeScreen === 'dashboard' ? (
                <button
                  type="button"
                  onClick={() => onNavigate('welcome')}
                  title="Return to Welcome Screen"
                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() =>
                    onNavigate(activeScreen === 'reports' ? 'function' : 'dashboard')
                  }
                  title="Go Back"
                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
                >
                  <ArrowLeft className="h-4.5 w-4.5" />
                </button>
              )}
              <div className="min-w-0">
                <h2 className="truncate text-sm font-semibold text-slate-900">
                  {activeScreen === 'dashboard' && appName}
                  {activeScreen === 'function' && domain.functionTitle}
                  {activeScreen === 'reports' && 'Reports & Recommendations'}
                </h2>
                <p className="truncate text-[11px] text-slate-500">
                  {activeScreen === 'dashboard' && `${domain.domainTitle} · Screen 2 of 4`}
                  {activeScreen === 'function' && `Core Input · Screen 3 of 4`}
                  {activeScreen === 'reports' && `Sample Results · Screen 4 of 4`}
                </p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1.5">
              {isNative && activeScreen === 'dashboard' && (
                <PWAInstallButton
                  compact
                  appName={appName}
                  onDownloadAndroidProject={onDownloadAndroidProject}
                />
              )}
              {activeScreen === 'dashboard' && (
                <button
                  type="button"
                  onClick={() => onNavigate('function')}
                  className="min-h-[40px] shrink-0 rounded-xl bg-slate-900 px-3 py-2 text-xs font-medium text-white transition-colors hover:bg-slate-800 whitespace-nowrap"
                >
                  Simulate
                </button>
              )}
              {activeScreen === 'reports' && activeReport && (
                <button
                  type="button"
                  onClick={handleCopyReport}
                  className="inline-flex min-h-[40px] shrink-0 items-center gap-1 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 whitespace-nowrap"
                >
                  {copiedReport ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-700" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <ClipboardCopy className="h-3.5 w-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </header>
        )}

        {/* Scrollable Screen Content */}
        <main
          className={`thin-scroll flex-1 overflow-y-auto px-4 py-4 ${
            isNative && activeScreen !== 'welcome' ? 'pb-24' : ''
          }`}
        >
          <div className={isNative ? 'mx-auto w-full max-w-lg' : 'w-full'}>
            {/* SCREEN 1: WELCOME / LOGIN */}
            {activeScreen === 'welcome' && (
              <div className="flex min-h-full flex-col justify-between py-2">
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>Screen 1 of 4 · Entry</span>
                    <span>Synthetic Prototype</span>
                  </div>

                  <div className="flex items-center gap-3.5 pt-1">
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white">
                      {!emblemError ? (
                        <img
                          src="/src/assets/images/brand_emblem_1795418280930.jpg"
                          alt={`${appName} emblem`}
                          referrerPolicy="no-referrer"
                          onError={() => setEmblemError(true)}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <LayoutDashboard className="h-7 w-7 text-teal-700" />
                      )}
                    </div>
                    <div>
                      <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                        {appName}
                      </h1>
                      <p className="text-xs font-medium text-teal-700">
                        {domain.domainTitle}
                      </p>
                    </div>
                  </div>

                  {/* Native mobile domain selector pills/buttons when in native mode */}
                  {isNative && onSelectDomain && (
                    <div className="rounded-2xl border border-slate-200 bg-white p-3">
                      <p className="text-[11px] font-medium text-slate-500">
                        Business Domain Focus
                      </p>
                      <div className="mt-2 grid grid-cols-3 gap-1.5 rounded-xl bg-slate-100 p-1">
                        {(Object.keys(BUSINESS_DOMAINS) as BusinessDomainId[]).map((id) => {
                          const d = BUSINESS_DOMAINS[id];
                          const active = id === domainId;
                          return (
                            <button
                              key={id}
                              type="button"
                              onClick={() => onSelectDomain(id)}
                              className={`min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] font-semibold transition-colors ${
                                active
                                  ? 'bg-white text-slate-900 shadow-xs'
                                  : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              {d.domainTitle.split(' ')[0]}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="rounded-2xl border border-slate-200 bg-white p-4">
                    <p className="text-sm font-medium text-slate-900">{domain.tagline}</p>
                    <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                      {domain.problemStatement}
                    </p>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      onChangeUserName(nameInput.trim() || domain.samplePersonaName);
                      onNavigate('dashboard');
                    }}
                    className="space-y-3.5 rounded-2xl border border-slate-200 bg-white p-4"
                  >
                    <div>
                      <label
                        htmlFor={`proto-name-${mode}`}
                        className="block text-xs font-medium text-slate-700"
                      >
                        Analyst Name (Sample Entry)
                      </label>
                      <input
                        id={`proto-name-${mode}`}
                        type="text"
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        placeholder={domain.samplePersonaName}
                        className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900 outline-none transition-colors focus:border-teal-700 focus:bg-white"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor={`proto-role-${mode}`}
                        className="block text-xs font-medium text-slate-700"
                      >
                        Business Role
                      </label>
                      <select
                        id={`proto-role-${mode}`}
                        value={userRole}
                        onChange={(e) => onChangeUserRole(e.target.value)}
                        className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900 outline-none transition-colors focus:border-teal-700 focus:bg-white"
                      >
                        <option value={domain.samplePersonaRole}>
                          {domain.samplePersonaRole}
                        </option>
                        <option value="MBA Operations Reviewer">
                          MBA Operations Reviewer
                        </option>
                        <option value="Regional Business Lead">
                          Regional Business Lead
                        </option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-teal-800 active:scale-[0.99]"
                    >
                      <span>Continue to Dashboard</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </form>
                </div>

                <div className="mt-4 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[11px] leading-relaxed text-slate-500">
                  Prototype entry only · No live authentication or external AI backend required. All figures use synthetic sample datasets.
                </div>
              </div>
            )}

            {/* SCREEN 2: BUSINESS DASHBOARD */}
            {activeScreen === 'dashboard' && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3.5">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full border border-slate-200 bg-slate-100">
                    {!avatarError ? (
                      <img
                        src="/src/assets/images/manager_avatar_1795418281048.jpg"
                        alt="Sample Analyst Avatar"
                        referrerPolicy="no-referrer"
                        onError={() => setAvatarError(true)}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span className="text-xs font-semibold text-slate-700">AR</span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-900">
                      Hello, {userName}
                    </p>
                    <p className="truncate text-xs text-slate-500">
                      {userRole} · {domain.dashboardSubtitle}
                    </p>
                  </div>
                </div>

                {/* 2x2 KPI Grid */}
                <div className="grid grid-cols-2 gap-2.5">
                  {domain.metrics.map((metric) => (
                    <div
                      key={metric.id}
                      className="rounded-2xl border border-slate-200 bg-white p-3.5"
                    >
                      <p className="truncate text-[11px] font-medium text-slate-500">
                        {metric.label}
                      </p>
                      <p className="mt-1 text-xl font-bold tracking-tight text-slate-900 tabular-nums">
                        {metric.value}
                      </p>
                      <p
                        className={`mt-0.5 text-[11px] font-medium ${
                          metric.tone === 'positive'
                            ? 'text-emerald-700'
                            : metric.tone === 'warning'
                            ? 'text-amber-700'
                            : 'text-slate-500'
                        }`}
                      >
                        {metric.delta}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Compact Bar Trend */}
                <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-900">
                      {domain.trendTitle}
                    </p>
                    <span className="text-[11px] text-slate-500">Synthetic</span>
                  </div>
                  <div className="mt-3 grid h-20 grid-cols-6 items-end gap-2">
                    {domain.trendPoints.map((pt, idx) => {
                      const heightPct = Math.max(
                        18,
                        Math.round((pt.value / maxTrend) * 100)
                      );
                      const isLatest = idx === domain.trendPoints.length - 1;
                      return (
                        <div
                          key={pt.label}
                          className="flex h-full flex-col items-center justify-end gap-1"
                        >
                          <div
                            className={`w-full rounded-md transition-all ${
                              isLatest ? 'bg-teal-700' : 'bg-slate-200'
                            }`}
                            style={{ height: `${heightPct}%` }}
                            title={`${pt.label}: ${pt.value}`}
                          />
                          <span className="text-[10px] font-medium text-slate-500 tabular-nums">
                            {pt.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Monitored Items List */}
                <div className="rounded-2xl border border-slate-200 bg-white">
                  <div className="flex items-center justify-between border-b border-slate-100 px-3.5 py-2.5">
                    <h3 className="text-xs font-semibold text-slate-900">
                      {domain.listSectionTitle}
                    </h3>
                    <span className="text-[11px] text-slate-500">Tap row to simulate</span>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {domain.records.map((rec) => (
                      <button
                        key={rec.id}
                        type="button"
                        onClick={() => onSelectRecord(rec, true)}
                        className="flex min-h-[60px] w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left transition-colors hover:bg-slate-50"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-xs font-semibold text-slate-900">
                            {rec.name}
                          </p>
                          <p className="mt-0.5 truncate text-[11px] text-slate-500">
                            {rec.code} · {rec.category} · {rec.primaryStatValue}
                          </p>
                        </div>
                        <div className="shrink-0 text-right">
                          {renderToneBadgeText(rec.statusTone, rec.statusText)}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* SCREEN 3: MAIN BUSINESS FUNCTION */}
            {activeScreen === 'function' && (
              <div className="space-y-3.5">
                <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
                  <label
                    htmlFor={`sim-record-select-${mode}`}
                    className="block text-[11px] font-medium text-slate-500"
                  >
                    Target Sample Record
                  </label>
                  <select
                    id={`sim-record-select-${mode}`}
                    value={inputs.selectedRecordId}
                    onChange={(e) => {
                      const found = domain.records.find(
                        (r) => r.id === e.target.value
                      );
                      if (found) onSelectRecord(found, false);
                    }}
                    className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-medium text-slate-900 outline-none focus:border-teal-700 focus:bg-white"
                  >
                    {domain.records.map((rec) => (
                      <option key={rec.id} value={rec.id}>
                        {rec.code} — {rec.name}
                      </option>
                    ))}
                  </select>
                  <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
                    {domain.functionSubtitle}
                  </p>
                </div>

                {/* Interactive Parameter Controls */}
                <div className="space-y-3.5 rounded-2xl border border-slate-200 bg-white p-3.5">
                  {(
                    [
                      { key: 'paramA' as const, meta: domain.paramLabels.a },
                      { key: 'paramB' as const, meta: domain.paramLabels.b },
                      { key: 'paramC' as const, meta: domain.paramLabels.c },
                      { key: 'paramD' as const, meta: domain.paramLabels.d },
                    ] as const
                  ).map(({ key, meta }) => (
                    <div key={key} className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-slate-700">
                          {meta.label}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            aria-label={`Decrease ${meta.label}`}
                            onClick={() =>
                              handleStepParam(key, -meta.step, meta.min, meta.max)
                            }
                            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="min-w-[64px] text-right font-mono text-xs font-semibold text-slate-900 tabular-nums">
                            {meta.unit === '$'
                              ? `$${inputs[key]}`
                              : `${inputs[key]} ${meta.unit}`}
                          </span>
                          <button
                            type="button"
                            aria-label={`Increase ${meta.label}`}
                            onClick={() =>
                              handleStepParam(key, meta.step, meta.min, meta.max)
                            }
                            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <input
                        type="range"
                        min={meta.min}
                        max={meta.max}
                        step={meta.step}
                        value={inputs[key]}
                        onChange={(e) =>
                          onChangeInputs({ ...inputs, [key]: Number(e.target.value) })
                        }
                        className="h-2 w-full cursor-pointer accent-teal-700"
                      />
                    </div>
                  ))}
                </div>

                {/* Scenario Segmented Selector */}
                <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
                  <p className="text-xs font-medium text-slate-700">
                    Scenario Assumption
                  </p>
                  <div className="mt-2 grid grid-cols-3 gap-1.5 rounded-xl bg-slate-100 p-1">
                    {domain.scenarioOptions.map((opt) => {
                      const active = inputs.scenario === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() =>
                            onChangeInputs({ ...inputs, scenario: opt.id })
                          }
                          className={`min-h-[44px] rounded-lg px-2 py-1.5 text-center transition-colors ${
                            active
                              ? 'bg-white text-slate-900 shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          <span className="block text-[11px] font-semibold">
                            {opt.label}
                          </span>
                          <span className="block text-[10px] text-slate-500">
                            {opt.multiplierText}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onRunSimulation}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-teal-800 active:scale-[0.99]"
                >
                  <span>Generate Sample Results</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* SCREEN 4: REPORTS / RESULTS / RECOMMENDATIONS */}
            {activeScreen === 'reports' && (
              <div className="space-y-3.5">
                <div className="rounded-2xl border border-teal-200 bg-teal-50/70 px-3.5 py-2.5">
                  <p className="text-xs font-semibold text-teal-900">
                    Sample Results · Local Synthetic Output
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-teal-800">
                    {activeReport
                      ? activeReport.sampleDisclaimer
                      : 'Run a simulation on Screen 3 to generate local sample recommendations.'}
                  </p>
                </div>

                {activeReport && (
                  <>
                    <div className="rounded-2xl border border-slate-200 bg-white p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-[11px] font-medium text-slate-500">
                            {activeReport.headlineLabel}
                          </p>
                          <p className="mt-0.5 text-3xl font-bold tracking-tight text-slate-900 tabular-nums">
                            {activeReport.headlineValue}
                          </p>
                        </div>
                        <div className="shrink-0 pt-1">
                          {renderToneBadgeText(
                            activeReport.riskTone,
                            activeReport.riskLabel
                          )}
                        </div>
                      </div>

                      <p className="mt-2 truncate text-xs text-slate-600">
                        {activeReport.itemName} · {activeReport.scenarioLabel}
                      </p>

                      <div className="mt-3.5 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
                        {activeReport.secondaryMetrics.map((m) => (
                          <div key={m.label}>
                            <p className="text-[11px] text-slate-500">{m.label}</p>
                            <p className="text-xs font-semibold text-slate-900 tabular-nums">
                              {m.value}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white">
                      <div className="border-b border-slate-100 px-3.5 py-2.5">
                        <h3 className="text-xs font-semibold text-slate-900">
                          Actionable Recommendations (Sample Results)
                        </h3>
                      </div>
                      <div className="divide-y divide-slate-100">
                        {activeReport.recommendations.map((rec, idx) => (
                          <div key={rec.title} className="px-3.5 py-3">
                            <p className="text-xs font-semibold text-slate-900">
                              {idx + 1}. {rec.title}
                            </p>
                            <p className="mt-1 text-[11px] leading-relaxed text-slate-600">
                              {rec.detail}
                            </p>
                            <p className="mt-1 text-[11px] font-medium text-teal-700">
                              Expected effect: {rec.impact}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white">
                      <div className="flex items-center justify-between border-b border-slate-100 px-3.5 py-2.5">
                        <h3 className="text-xs font-semibold text-slate-900">
                          Local Scenario History ({history.length})
                        </h3>
                        <span className="text-[11px] text-slate-500">Tap to inspect</span>
                      </div>
                      <div className="divide-y divide-slate-100">
                        {history.map((item) => {
                          const isSelected = item.id === activeReport.id;
                          return (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => onSelectReportId(item.id)}
                              className={`flex min-h-[48px] w-full items-center justify-between gap-2 px-3.5 py-2 text-left transition-colors ${
                                isSelected ? 'bg-teal-50/70' : 'hover:bg-slate-50'
                              }`}
                            >
                              <div className="min-w-0">
                                <p className="truncate text-xs font-medium text-slate-900">
                                  {item.itemName}
                                </p>
                                <p className="truncate text-[11px] text-slate-500">
                                  {item.scenarioLabel} · {item.timestamp}
                                </p>
                              </div>
                              <span className="shrink-0 font-mono text-xs font-semibold text-slate-900 tabular-nums">
                                {item.headlineValue}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}

                <button
                  type="button"
                  onClick={() => onNavigate('function')}
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Adjust Inputs &amp; Re-Run</span>
                </button>
              </div>
            )}
          </div>
        </main>

        {/* Material 3 Bottom Navigation Bar (Screens 2, 3, 4) */}
        {activeScreen !== 'welcome' && (
          <nav
            aria-label="Mobile App Navigation"
            className={`${
              isNative ? 'fixed bottom-0 left-0 right-0 z-30' : 'shrink-0'
            } grid h-16 grid-cols-3 border-t border-slate-200 bg-white/95 px-2 backdrop-blur-md`}
          >
            {(
              [
                { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
                { id: 'function' as const, label: 'Simulate', icon: SlidersHorizontal },
                { id: 'reports' as const, label: 'Reports', icon: BarChart3 },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const isActive = activeScreen === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => onNavigate(tab.id)}
                  className="flex min-h-[48px] flex-col items-center justify-center gap-1 rounded-xl transition-colors"
                >
                  <span
                    className={`flex h-7 w-14 items-center justify-center rounded-full transition-colors ${
                      isActive ? 'bg-teal-100 text-teal-900' : 'text-slate-500'
                    }`}
                  >
                    <Icon className="h-4.5 w-4.5" />
                  </span>
                  <span
                    className={`text-[11px] font-medium ${
                      isActive ? 'text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </nav>
        )}

        {/* Android Gesture Handle Bar (only in framed preview) */}
        {!isNative && (
          <div className="flex h-5 shrink-0 items-center justify-center bg-white">
            <div className="h-1 w-24 rounded-full bg-slate-300" aria-hidden="true" />
          </div>
        )}
      </div>
    </div>
  );
};
