import React, { useState } from 'react';
import {
  Check,
  CheckSquare,
  Code2,
  Copy,
  Download,
  FileCode2,
  FolderOpen,
  Layers,
  Play,
  Smartphone,
  Video,
} from 'lucide-react';
import {
  BUSINESS_DOMAINS,
  BusinessDomainId,
  DomainConfig,
  ScreenId,
  SimulationInputs,
  SimulationResult,
} from '../data/domains';
import { AndroidSourceFile } from '../data/androidSourceCode';

export type WorkbenchTab = 'emulator' | 'code' | 'architecture' | 'guide';

interface WorkbenchPanelsProps {
  activeTab: WorkbenchTab;
  domainId: BusinessDomainId;
  onSelectDomain: (id: BusinessDomainId) => void;
  appName: string;
  onChangeAppName: (name: string) => void;
  domain: DomainConfig;
  activeScreen: ScreenId;
  onNavigateScreen: (screen: ScreenId) => void;
  userName: string;
  inputs: SimulationInputs;
  history: SimulationResult[];
  androidFiles: AndroidSourceFile[];
  onDownloadZip: () => void;
}

export const WorkbenchPanels: React.FC<WorkbenchPanelsProps> = ({
  activeTab,
  domainId,
  onSelectDomain,
  appName,
  onChangeAppName,
  domain,
  activeScreen,
  onNavigateScreen,
  userName,
  inputs,
  history,
  androidFiles,
  onDownloadZip,
}) => {
  const [selectedFileId, setSelectedFileId] = useState<string>(
    androidFiles[0]?.id || 'main-activity'
  );
  const [copiedFile, setCopiedFile] = useState(false);

  const selectedFile =
    androidFiles.find((f) => f.id === selectedFileId) || androidFiles[0];

  const handleCopyCode = () => {
    if (!selectedFile) return;
    navigator.clipboard?.writeText(selectedFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 1800);
  };

  const screenSteps: { id: ScreenId; num: string; title: string; role: string }[] = [
    {
      id: 'welcome',
      num: 'Screen 1',
      title: 'Welcome / Login',
      role: 'App intro & basic sample entry point',
    },
    {
      id: 'dashboard',
      num: 'Screen 2',
      title: 'Business Dashboard',
      role: 'Summary metrics, trend & item list',
    },
    {
      id: 'function',
      num: 'Screen 3',
      title: 'Main Business Function',
      role: 'Interactive local calculation & simulation',
    },
    {
      id: 'reports',
      num: 'Screen 4',
      title: 'Reports & Recommendations',
      role: 'Outputs labeled Sample Results + history',
    },
  ];

  return (
    <div className="space-y-6">
      {/* TAB 1: EMULATOR & DOMAIN FLOW */}
      {activeTab === 'emulator' && (
        <>
          {/* Section 3 Domain Switcher & Customizer */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">
                  01. Business Domain & Prototype Customizer
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Select your MBA Section 3 business domain or customize the prototype app name before capturing screenshots.
                </p>
              </div>
              <span className="text-xs font-medium text-slate-500">
                Synthetic Data Only
              </span>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
              {(Object.keys(BUSINESS_DOMAINS) as BusinessDomainId[]).map((id) => {
                const d = BUSINESS_DOMAINS[id];
                const active = id === domainId;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onSelectDomain(id)}
                    className={`min-h-[56px] rounded-xl border p-3 text-left transition-colors ${
                      active
                        ? 'border-teal-700 bg-teal-50/70 text-slate-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="block text-xs font-semibold">{d.domainTitle}</span>
                    <span className="mt-0.5 block truncate text-[11px] text-slate-500">
                      {d.defaultAppName}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="custom-app-name"
                  className="block text-xs font-medium text-slate-700"
                >
                  Prototype App Name (Updates UI & Kotlin Package)
                </label>
                <input
                  id="custom-app-name"
                  type="text"
                  value={appName}
                  onChange={(e) => onChangeAppName(e.target.value)}
                  className="mt-1.5 h-10 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900 outline-none focus:border-teal-700 focus:bg-white"
                />
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5">
                <p className="text-xs font-medium text-slate-700">Selected Problem Focus</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                  {domain.problemStatement}
                </p>
              </div>
            </div>
          </section>

          {/* 4-Screen Quick Navigator (Screenshot Helper) */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">
                  02. Connected 4-Screen Navigation
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Click inside the Android screen on the left or jump directly between screens to capture your 4+ required screenshots.
                </p>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {screenSteps.map((step) => {
                const isActive = activeScreen === step.id;
                return (
                  <button
                    key={step.id}
                    type="button"
                    onClick={() => onNavigateScreen(step.id)}
                    className={`flex min-h-[64px] items-start gap-3 rounded-xl border p-3.5 text-left transition-colors ${
                      isActive
                        ? 'border-teal-700 bg-teal-50/70'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <Smartphone
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        isActive ? 'text-teal-700' : 'text-slate-400'
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900">
                        {step.num} · {step.title}
                      </p>
                      <p className="mt-0.5 text-[11px] text-slate-500">{step.role}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Live Local Data Flow Inspector */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-lg font-semibold text-slate-900">
                03. Live Local Data Flow State
              </h2>
              <span className="text-xs font-medium text-teal-700">
                In-Memory Only · No Backend
              </span>
            </div>
            <p className="mt-1 text-sm text-slate-600">
              Changes made on Screen 1, Screen 2, or Screen 3 update this shared local state and recompute Screen 4 Sample Results immediately.
            </p>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p className="text-[11px] text-slate-500">Signed-In User</p>
                <p className="mt-1 truncate text-xs font-semibold text-slate-900">
                  {userName}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p className="text-[11px] text-slate-500">Active Item</p>
                <p className="mt-1 truncate text-xs font-semibold text-slate-900">
                  {inputs.itemName}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p className="text-[11px] text-slate-500">Scenario Mode</p>
                <p className="mt-1 truncate text-xs font-semibold text-slate-900 capitalize">
                  {inputs.scenario}
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <p className="text-[11px] text-slate-500">Saved Runs</p>
                <p className="mt-1 font-mono text-xs font-semibold text-slate-900 tabular-nums">
                  {history.length} Sample Results
                </p>
              </div>
            </div>
          </section>
        </>
      )}

      {/* TAB 2: KOTLIN & JAVA SOURCE CODE */}
      {activeTab === 'code' && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                Android Studio Source Code (Kotlin Jetpack Compose + Java)
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Generated specifically for <span className="font-medium text-slate-900">{appName}</span> ({domain.domainTitle}). Ready to paste or import into Android Studio.
              </p>
            </div>
            <button
              type="button"
              onClick={onDownloadZip}
              className="inline-flex h-10 shrink-0 items-center gap-2 rounded-xl bg-teal-700 px-4 text-xs font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap"
            >
              <Download className="h-4 w-4" />
              <span>Download Full Project (.zip)</span>
            </button>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
            {/* File Tree */}
            <div className="space-y-1 lg:col-span-4">
              {androidFiles.map((file) => {
                const active = file.id === selectedFile?.id;
                return (
                  <button
                    key={file.id}
                    type="button"
                    onClick={() => setSelectedFileId(file.id)}
                    className={`flex min-h-[48px] w-full items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                      active
                        ? 'border-teal-700 bg-teal-50/70'
                        : 'border-transparent hover:bg-slate-50'
                    }`}
                  >
                    <FileCode2
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        active ? 'text-teal-700' : 'text-slate-400'
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="truncate font-mono text-xs font-semibold text-slate-900">
                        {file.fileName}
                      </p>
                      <p className="truncate text-[11px] text-slate-500">
                        {file.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Code Preview */}
            {selectedFile && (
              <div className="flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-slate-900 lg:col-span-8">
                <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs font-medium text-slate-200">
                      {selectedFile.zipPath}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs font-medium text-slate-200 hover:bg-slate-700"
                  >
                    {copiedFile ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy File</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="thin-scroll max-h-[540px] overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
                  <code>{selectedFile.content}</code>
                </pre>
              </div>
            )}
          </div>
        </section>
      )}

      {/* TAB 3: ARCHITECTURE & LOCAL DATA FLOW */}
      {activeTab === 'architecture' && (
        <div className="space-y-6">
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2">
              <Layers className="h-5 w-5 text-teal-700" />
              <h2 className="text-lg font-semibold text-slate-900">
                4-Screen Architecture & Local Data Flow
              </h2>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              {appName} uses a single-activity Jetpack Compose architecture with a shared in-memory state container. Data flows strictly locally across the four screens using deterministic business formulas—no external API keys, sensitive PII, or live AI claims are used.
            </p>

            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-xs font-semibold text-teal-700">01. WelcomeScreen.kt</p>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  Prototype Entry & Role Context
                </p>
                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                  Captures a sample analyst name and role into local state without requiring a live authentication server, then clears the backstack into the Dashboard.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-xs font-semibold text-teal-700">02. DashboardScreen.kt</p>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  KPI Summary & Record Selection
                </p>
                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                  Renders synthetic KPI cards, a 6-period bar trend, and selectable sample records from <span className="font-mono">SampleRepository</span>. Tapping any row pre-populates Screen 3.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-xs font-semibold text-teal-700">03. SimulationScreen.kt</p>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  Core Business Logic Simulator
                </p>
                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                  Provides sliders, steppers, and scenario toggles. Submitting invokes <span className="font-mono">BusinessLogicEngine.calculate()</span> and appends the result to history.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-4">
                <p className="text-xs font-semibold text-teal-700">04. ReportsScreen.kt</p>
                <p className="mt-1 text-sm font-semibold text-slate-900">
                  Sample Results & Recommendations
                </p>
                <p className="mt-1 text-xs leading-relaxed text-slate-600">
                  Explicitly labels all metrics and action items as <span className="font-semibold">Sample Results</span>, displays scenario history, and supports text summary copying.
                </p>
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <h3 className="text-base font-semibold text-slate-900">
              Academic & Data Integrity Checklist
            </h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li>
                <span className="font-medium text-slate-900">No Live AI Claimed:</span>{' '}
                All forecasts and recommendations are deterministic calculations over synthetic inputs and are labeled &ldquo;Sample Results&rdquo;.
              </li>
              <li>
                <span className="font-medium text-slate-900">Zero Sensitive PII:</span>{' '}
                Names, SKU codes, marketing channels, and HR cohorts are 100% synthetic placeholder records.
              </li>
              <li>
                <span className="font-medium text-slate-900">Kotlin + Java Ready:</span>{' '}
                Includes complete Material 3 Jetpack Compose files plus a Java AppCompat reference entry point.
              </li>
            </ul>
          </section>
        </div>
      )}

      {/* TAB 4: PACKAGING & DEMO VIDEO GUIDE */}
      {activeTab === 'guide' && (
        <div className="space-y-6">
          {/* Step 1: Android Studio & APK */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-teal-700" />
                <h2 className="text-lg font-semibold text-slate-900">
                  How to Package Source Code & Build APK
                </h2>
              </div>
              <button
                type="button"
                onClick={onDownloadZip}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-800 hover:bg-slate-100"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download .zip</span>
              </button>
            </div>

            <ol className="mt-4 space-y-3 text-sm text-slate-600">
              <li>
                <span className="font-semibold text-slate-900">1. Create Project in Android Studio:</span>{' '}
                Choose <span className="font-mono text-xs">Empty Activity (Compose)</span> with package name{' '}
                <span className="font-mono text-xs">
                  com.mba.prototype.{appName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'bizpulse'}
                </span>{' '}
                and Minimum SDK 24 (Android 7.0).
              </li>
              <li>
                <span className="font-semibold text-slate-900">2. Drop in Downloaded Files:</span>{' '}
                Extract the downloaded zip and copy the <span className="font-mono text-xs">.kt</span> files and{' '}
                <span className="font-mono text-xs">app/build.gradle.kts</span> dependencies, then click{' '}
                <span className="font-medium text-slate-900">Sync Now</span>.
              </li>
              <li>
                <span className="font-semibold text-slate-900">3. Run on Emulator / Device:</span>{' '}
                Select a Pixel API 34 emulator (or USB-debugging phone) and press{' '}
                <span className="font-medium text-slate-900">Run &lsquo;app&rsquo;</span>.
              </li>
              <li>
                <span className="font-semibold text-slate-900">4. Generate Debug APK:</span>{' '}
                In Android Studio click{' '}
                <span className="font-mono text-xs">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</span>{' '}
                (or run <span className="font-mono text-xs">./gradlew assembleDebug</span>). Submit{' '}
                <span className="font-mono text-xs">app-debug.apk</span> alongside the zipped source folder.
              </li>
            </ol>
          </section>

          {/* Step 2: 4+ Screenshots Checklist */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2">
              <CheckSquare className="h-5 w-5 text-teal-700" />
              <h2 className="text-lg font-semibold text-slate-900">
                4+ Required Screenshots Checklist
              </h2>
            </div>
            <p className="mt-1 text-sm text-slate-600">
              Click any button below to jump the interactive emulator to that exact screen for clean capture.
            </p>
            <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {screenSteps.map((step) => (
                <button
                  key={step.id}
                  type="button"
                  onClick={() => onNavigateScreen(step.id)}
                  className="flex min-h-[56px] items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition-colors hover:border-teal-700 hover:bg-teal-50/60"
                >
                  <div>
                    <p className="text-xs font-semibold text-slate-900">
                      {step.num}: {step.title}
                    </p>
                    <p className="text-[11px] text-slate-500">{step.role}</p>
                  </div>
                  <Play className="h-4 w-4 shrink-0 text-teal-700" />
                </button>
              ))}
            </div>
          </section>

          {/* Step 3: 2-3 Minute Demo Video Outline */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6">
            <div className="flex items-center gap-2">
              <Video className="h-5 w-5 text-teal-700" />
              <h2 className="text-lg font-semibold text-slate-900">
                2–3 Minute Demo Video Script
              </h2>
            </div>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              <div className="rounded-xl border border-slate-200 p-3.5">
                <p className="text-xs font-semibold text-slate-900">
                  0:00 – 0:30 · Screen 1 (Welcome & Business Problem)
                </p>
                <p className="mt-1 text-xs leading-relaxed">
                  Introduce {appName} for {domain.domainTitle}. Explain the core MBA problem ({domain.problemStatement}) and note that no live authentication or AI backend is claimed—entry uses a sample analyst profile.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-3.5">
                <p className="text-xs font-semibold text-slate-900">
                  0:30 – 1:10 · Screen 2 (Business Dashboard)
                </p>
                <p className="mt-1 text-xs leading-relaxed">
                  Walk through the 4 KPI summary metrics, the 6-period synthetic trend chart, and tap one of the monitored items in the list to show how data carries directly into Screen 3.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-3.5">
                <p className="text-xs font-semibold text-slate-900">
                  1:10 – 2:00 · Screen 3 (Main Business Function)
                </p>
                <p className="mt-1 text-xs leading-relaxed">
                  Adjust at least two sliders/steppers and toggle the Scenario Mode (e.g., Baseline vs. {domain.scenarioOptions[2].label}). Tap &ldquo;Generate Sample Results&rdquo; to demonstrate live local data flow.
                </p>
              </div>
              <div className="rounded-xl border border-slate-200 p-3.5">
                <p className="text-xs font-semibold text-slate-900">
                  2:00 – 2:45 · Screen 4 (Reports & Sample Results + Wrap-up)
                </p>
                <p className="mt-1 text-xs leading-relaxed">
                  Point out the explicit &ldquo;Sample Results&rdquo; label, read the calculated headline output and 3 business recommendations, switch between runs in Local Scenario History, and briefly show the Kotlin project structure in Android Studio.
                </p>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
};
