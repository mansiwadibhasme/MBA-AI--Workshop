import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import {
  Check,
  Copy,
  Download,
  FileArchive,
  Smartphone,
  WifiOff,
  X,
} from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  appName?: string;
  onDownloadAndroidProject?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  compact = false,
  appName = 'BizPulse',
  onDownloadAndroidProject,
}) => {
  const { isInstallable, isInstalled, isIOS, isInIframe, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [modalTab, setModalTab] = useState<'phone' | 'apk'>('phone');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const shareUrl =
    typeof window !== 'undefined' ? window.location.origin : '';

  useEffect(() => {
    if (!showModal || !shareUrl) return;
    QRCode.toDataURL(shareUrl, {
      width: 176,
      margin: 1,
      color: { dark: '#0F172A', light: '#FFFFFF' },
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => setQrDataUrl(''));
  }, [showModal, shareUrl]);

  // Suppress button when already running in standalone installed mode
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        setShowModal(true);
      }
      return;
    }
    setShowModal(true);
  };

  const handleCopyUrl = () => {
    navigator.clipboard?.writeText(shareUrl || window.location.href);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 1800);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={
          compact
            ? 'inline-flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-xl bg-teal-700 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap'
            : 'inline-flex h-10 shrink-0 items-center gap-2 rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap'
        }
      >
        <Download className="h-3.5 w-3.5 shrink-0" />
        <span>{compact ? 'Install App' : 'Install on Phone'}</span>
      </button>

      {showModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="pwa-install-title"
          className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-4 backdrop-blur-xs sm:items-center"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
                  <Smartphone className="h-5 w-5" />
                </div>
                <div>
                  <h3
                    id="pwa-install-title"
                    className="text-base font-semibold text-slate-900"
                  >
                    Install {appName} on Your Phone
                  </h3>
                  <p className="text-xs text-slate-500">
                    Choose instant mobile install or Android Studio APK
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close install dialog"
                onClick={() => setShowModal(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Segmented Mode Switcher */}
            <div className="mt-4 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => setModalTab('phone')}
                className={`min-h-[40px] rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                  modalTab === 'phone'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1. Phone Home Screen
              </button>
              <button
                type="button"
                onClick={() => setModalTab('apk')}
                className={`min-h-[40px] rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                  modalTab === 'apk'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2. Android APK (.zip)
              </button>
            </div>

            {modalTab === 'phone' ? (
              <div className="mt-4 space-y-3.5">
                {isInIframe && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs leading-relaxed text-amber-900">
                    AI Studio previews run inside an embedded frame. Scan this QR code or copy the link to open directly in your phone&rsquo;s browser, then install.
                  </div>
                )}

                {qrDataUrl && (
                  <div className="flex items-center gap-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
                    <img
                      src={qrDataUrl}
                      alt={`QR code to open ${appName} on mobile`}
                      className="h-24 w-24 shrink-0 rounded-lg border border-slate-200 bg-white p-1"
                    />
                    <div className="text-xs leading-relaxed text-slate-600">
                      <p className="font-semibold text-slate-900">
                        Scan with Phone Camera
                      </p>
                      <p className="mt-1">
                        Opens {appName} directly in full-screen mobile mode so you can add it to your phone&rsquo;s home screen.
                      </p>
                    </div>
                  </div>
                )}

                {isIOS ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
                    <p className="font-semibold text-slate-900">
                      iPhone / iPad (Safari):
                    </p>
                    <ol className="mt-1 list-decimal space-y-0.5 pl-4">
                      <li>Open the link in Safari.</li>
                      <li>Tap <strong>Share</strong> in the bottom bar.</li>
                      <li>Tap <strong>Add to Home Screen</strong>.</li>
                    </ol>
                  </div>
                ) : (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
                    <p className="font-semibold text-slate-900">
                      Android (Chrome / Edge):
                    </p>
                    <ol className="mt-1 list-decimal space-y-0.5 pl-4">
                      <li>Open the link in Chrome on your Android phone.</li>
                      <li>Tap <strong>Install App</strong> (or Chrome menu <strong>⋮ &gt; Install app</strong>).</li>
                      <li>Launch <strong>{appName}</strong> from your phone&rsquo;s app drawer.</li>
                    </ol>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={shareUrl}
                    aria-label="Direct Mobile App URL"
                    className="h-10 min-w-0 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 font-mono text-[11px] text-slate-700 outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleCopyUrl}
                    className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-800 hover:bg-slate-100"
                  >
                    {copiedUrl ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-700" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy Link</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-4 space-y-3.5">
                <p className="text-xs leading-relaxed text-slate-600">
                  Google AI Studio runs as a web preview and cannot compile a binary <span className="font-mono">.apk</span> file inside the browser. To install as a native Android <span className="font-mono">.apk</span>:
                </p>

                <ol className="space-y-2 rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs leading-relaxed text-slate-700">
                  <li>
                    <strong>1. Download</strong> the complete Android Studio Gradle project below and unzip it.
                  </li>
                  <li>
                    <strong>2. Open in Android Studio</strong> (<span className="font-mono">File &gt; Open</span>) and wait for Gradle Sync.
                  </li>
                  <li>
                    <strong>3. Build APK</strong> (<span className="font-mono">Build &gt; Build APK(s)</span>) and transfer <span className="font-mono">app-debug.apk</span> to your Android phone to install.
                  </li>
                </ol>

                {onDownloadAndroidProject && (
                  <button
                    type="button"
                    onClick={onDownloadAndroidProject}
                    className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 text-xs font-semibold text-white transition-colors hover:bg-teal-800"
                  >
                    <FileArchive className="h-4 w-4" />
                    <span>Download Android Studio Project (.zip)</span>
                  </button>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="mt-4 h-11 w-full rounded-xl bg-slate-900 text-xs font-semibold text-white transition-colors hover:bg-slate-800"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-medium text-amber-900 shadow-lg"
    >
      <WifiOff className="h-3.5 w-3.5 shrink-0 text-amber-700" />
      <span>Offline Mode · Cached synthetic data active</span>
    </div>
  );
};
