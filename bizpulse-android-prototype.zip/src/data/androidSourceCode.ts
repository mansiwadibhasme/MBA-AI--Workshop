import { BusinessDomainId, BUSINESS_DOMAINS } from './domains';

export interface AndroidSourceFile {
  id: string;
  fileName: string;
  zipPath: string;
  language: 'kotlin' | 'java' | 'xml' | 'gradle' | 'text';
  description: string;
  content: string;
}

export function generateAndroidProjectFiles(
  domainId: BusinessDomainId,
  customAppName: string
): AndroidSourceFile[] {
  const domain = BUSINESS_DOMAINS[domainId];
  const appName = customAppName.trim() || domain.defaultAppName;
  const cleanClassName = appName.replace(/[^A-Za-z0-9]/g, '') || 'BizPulse';
  const packageSlug = appName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'bizpulse';
  const pkg = `com.mba.prototype.${packageSlug}`;
  const pkgPath = pkg.replace(/\./g, '/');

  const firstRecord = domain.records[0];

  const mainActivityKt = `package ${pkg}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

/**
 * ${appName} - Android Business Prototype (${domain.domainTitle})
 * Connects 4 Material 3 screens with local synthetic state flow.
 * Note: Uses predefined/synthetic data only; no live AI backend is claimed.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF0F766E),
                    secondary = Color(0xFF0F172A),
                    surface = Color(0xFFFFFFFF),
                    background = Color(0xFFF8FAFC)
                )
            ) {
                ${cleanClassName}App()
            }
        }
    }
}

sealed class Screen(val route: String, val label: String) {
    data object Welcome : Screen("welcome", "Welcome")
    data object Dashboard : Screen("dashboard", "Dashboard")
    data object Function : Screen("function", "Simulate")
    data object Reports : Screen("reports", "Reports")
}

@Composable
fun ${cleanClassName}App() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Screen.Welcome.route

    // Shared local state across the 4 screens
    var userName by remember { mutableStateOf("${domain.samplePersonaName}") }
    var selectedRecord by remember { mutableStateOf(SampleRepository.records.first()) }
    val simulationHistory = remember {
        mutableStateListOf(
            BusinessLogicEngine.calculate(
                itemName = SampleRepository.records.first().name,
                paramA = ${firstRecord.paramA},
                paramB = ${firstRecord.paramB},
                paramC = ${firstRecord.paramC},
                paramD = ${firstRecord.paramD},
                scenario = ScenarioType.BASELINE
            )
        )
    }

    Scaffold(
        bottomBar = {
            if (currentRoute != Screen.Welcome.route) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == Screen.Dashboard.route,
                        onClick = { navController.navigate(Screen.Dashboard.route) },
                        icon = { Icon(Icons.Outlined.Dashboard, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Function.route,
                        onClick = { navController.navigate(Screen.Function.route) },
                        icon = { Icon(Icons.Outlined.Analytics, contentDescription = "Simulate") },
                        label = { Text("Simulate") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Reports.route,
                        onClick = { navController.navigate(Screen.Reports.route) },
                        icon = { Icon(Icons.Outlined.Assessment, contentDescription = "Reports") },
                        label = { Text("Reports") }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Welcome.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Welcome.route) {
                WelcomeScreen(
                    appName = "${appName}",
                    tagline = "${domain.tagline}",
                    initialUser = userName,
                    onContinue = { enteredName ->
                        userName = enteredName.ifBlank { "${domain.samplePersonaName}" }
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Welcome.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    userName = userName,
                    records = SampleRepository.records,
                    onSelectForSimulation = { record ->
                        selectedRecord = record
                        navController.navigate(Screen.Function.route)
                    },
                    onOpenSimulation = { navController.navigate(Screen.Function.route) },
                    onOpenReports = { navController.navigate(Screen.Reports.route) }
                )
            }
            composable(Screen.Function.route) {
                SimulationScreen(
                    record = selectedRecord,
                    onRunSimulation = { result ->
                        simulationHistory.add(0, result)
                        navController.navigate(Screen.Reports.route)
                    }
                )
            }
            composable(Screen.Reports.route) {
                ReportsScreen(
                    results = simulationHistory,
                    onRunAnother = { navController.navigate(Screen.Function.route) }
                )
            }
        }
    }
}
`;

  const businessModelsKt = `package ${pkg}

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

enum class ScenarioType(val label: String, val factor: Double) {
    BASELINE("${domain.scenarioOptions[0].label}", 1.0),
    MODERATE("${domain.scenarioOptions[1].label}", 1.25),
    PEAK("${domain.scenarioOptions[2].label}", 1.45)
}

data class SampleBusinessRecord(
    val id: String,
    val code: String,
    val name: String,
    val category: String,
    val statusText: String,
    val paramA: Int,
    val paramB: Int,
    val paramC: Int,
    val paramD: Int
)

data class SampleSimulationResult(
    val itemName: String,
    val scenarioLabel: String,
    val headlineLabel: String,
    val headlineValue: String,
    val secondarySummary: String,
    val riskStatus: String,
    val recommendations: List<String>,
    val sampleNotice: String = "Sample Results (Local Synthetic Calculation)"
)

object SampleRepository {
    val records = listOf(
${domain.records
  .map(
    (r) =>
      `        SampleBusinessRecord("${r.id}", "${r.code}", "${r.name}", "${r.category}", "${r.statusText}", ${r.paramA}, ${r.paramB}, ${r.paramC}, ${r.paramD})`
  )
  .join(',\n')}
    )
}

object BusinessLogicEngine {
    fun calculate(
        itemName: String,
        paramA: Int,
        paramB: Int,
        paramC: Int,
        paramD: Int,
        scenario: ScenarioType
    ): SampleSimulationResult {
${
  domainId === 'retail'
    ? `        val adjustedDemand = paramB * scenario.factor
        val safetyStock = ceil(adjustedDemand * 4).toInt()
        val reorderPoint = ceil(adjustedDemand * paramC + safetyStock).toInt()
        val daysSupply = ((paramA / max(1.0, adjustedDemand)) * 10).roundToInt() / 10.0
        val orderQty = max(25, ceil(adjustedDemand * 21).toInt())
        val risk = if (paramA <= reorderPoint) "Critical Reorder Needed" else "Healthy Coverage"
        return SampleSimulationResult(
            itemName = itemName,
            scenarioLabel = scenario.label,
            headlineLabel = "Calculated Reorder Point",
            headlineValue = "$reorderPoint units",
            secondarySummary = "Days of Supply: $daysSupply d | Recommended Order: $orderQty units | Est. Cost: $" + (orderQty * paramD),
            riskStatus = risk,
            recommendations = listOf(
                "Place replenishment order of $orderQty units to cover $paramC-day lead time.",
                "Maintain $safetyStock units of safety stock for demand variability.",
                "Review SKU velocity weekly using local synthetic benchmarks."
            )
        )`
    : domainId === 'marketing'
    ? `        val effectiveConv = (paramC * scenario.factor).coerceAtMost(45.0)
        val leads = max(1, paramA / max(1, paramB))
        val closedDeals = max(1, ((leads * effectiveConv) / 100.0).roundToInt())
        val revenue = closedDeals * paramD
        val roas = ((revenue.toDouble() / max(1, paramA)) * 10).roundToInt() / 10.0
        val risk = if (roas >= 3.0) "Scale Budget Candidate" else "Optimize Conversion"
        return SampleSimulationResult(
            itemName = itemName,
            scenarioLabel = scenario.label,
            headlineLabel = "Projected Channel ROAS",
            headlineValue = "\${roas}x",
            secondarySummary = "Leads: $leads | Deals: $closedDeals | Est. Revenue: $$revenue",
            riskStatus = risk,
            recommendations = listOf(
                "Allocate budget toward channels sustaining >= 3.0x sample ROAS.",
                "Improve speed-to-lead follow-up to lift conversion above $paramC%.",
                "Audit cost-per-lead thresholds biweekly."
            )
        )`
    : `        val otReduction = if (scenario == ScenarioType.PEAK) 4 else if (scenario == ScenarioType.MODERATE) 3 else 0
        val effectiveOt = max(0, paramC - otReduction)
        val riskPct = (8 + max(0, 9 - paramB) * 4 + effectiveOt * 2 + max(0, 100 - paramD)).coerceIn(6, 68)
        val estDepartures = max(1, ((paramA * riskPct) / 100.0).roundToInt())
        val risk = if (riskPct >= 28) "High Attrition Risk" else "Monitor Cohort"
        return SampleSimulationResult(
            itemName = itemName,
            scenarioLabel = scenario.label,
            headlineLabel = "Projected Attrition Risk",
            headlineValue = "$riskPct%",
            secondarySummary = "Est. Departures: $estDepartures of $paramA | Effective OT: $effectiveOt hrs/wk",
            riskStatus = risk,
            recommendations = listOf(
                "Cap recurring overtime below 6 hrs/week to prevent cohort fatigue.",
                "Benchmark compensation index against market median.",
                "Track anonymized cohort engagement monthly (no PII stored)."
            )
        )`
}
    }
}
`;

  const welcomeScreenKt = `package ${pkg}

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Screen 1: Welcome / Prototype Entry
 * Basic entry point with no live authentication backend required.
 */
@Composable
fun WelcomeScreen(
    appName: String,
    tagline: String,
    initialUser: String,
    onContinue: (String) -> Unit
) {
    var nameInput by remember { mutableStateOf(initialUser) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "MBA Task 3 Prototype · Synthetic Data Only",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = appName,
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = tagline,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(28.dp))

        OutlinedTextField(
            value = nameInput,
            onValueChange = { nameInput = it },
            label = { Text("Analyst Name (Sample Entry)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { onContinue(nameInput) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Enter Business Dashboard")
        }
    }
}
`;

  const dashboardScreenKt = `package ${pkg}

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Screen 2: Business Dashboard
 * Displays summary KPIs and selectable sample records.
 */
@Composable
fun DashboardScreen(
    userName: String,
    records: List<SampleBusinessRecord>,
    onSelectForSimulation: (SampleBusinessRecord) -> Unit,
    onOpenSimulation: () -> Unit,
    onOpenReports: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Welcome, $userName", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(
                "${domain.dashboardSubtitle}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricBox("${domain.metrics[0].label}", "${domain.metrics[0].value}", Modifier.weight(1f))
                MetricBox("${domain.metrics[1].label}", "${domain.metrics[1].value}", Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenSimulation, modifier = Modifier.weight(1f)) {
                    Text("Run Simulation")
                }
                OutlinedButton(onClick = onOpenReports, modifier = Modifier.weight(1f)) {
                    Text("Sample Reports")
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("${domain.listSectionTitle}", style = MaterialTheme.typography.titleMedium)
        }

        items(records) { record ->
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectForSimulation(record) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("\${record.code} · \${record.name}", fontWeight = FontWeight.Medium)
                    Text(
                        "\${record.category} · \${record.statusText}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricBox(title: String, value: String, modifier: Modifier = Modifier) {
    OutlinedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}
`;

  const simulationScreenKt = `package ${pkg}

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Screen 3: Main Business Function
 * Interactive parameter adjustment & deterministic local simulation.
 */
@Composable
fun SimulationScreen(
    record: SampleBusinessRecord,
    onRunSimulation: (SampleSimulationResult) -> Unit
) {
    var paramA by remember(record) { mutableStateOf(record.paramA.toFloat()) }
    var paramB by remember(record) { mutableStateOf(record.paramB.toFloat()) }
    var paramC by remember(record) { mutableStateOf(record.paramC.toFloat()) }
    var paramD by remember(record) { mutableStateOf(record.paramD.toFloat()) }
    var scenario by remember { mutableStateOf(ScenarioType.BASELINE) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("${domain.functionTitle}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Selected: \${record.name}", style = MaterialTheme.typography.bodyMedium)

        Text("${domain.paramLabels.a.label}: \${paramA.toInt()} ${domain.paramLabels.a.unit}")
        Slider(value = paramA, onValueChange = { paramA = it }, valueRange = ${domain.paramLabels.a.min}f..${domain.paramLabels.a.max}f)

        Text("${domain.paramLabels.b.label}: \${paramB.toInt()} ${domain.paramLabels.b.unit}")
        Slider(value = paramB, onValueChange = { paramB = it }, valueRange = ${domain.paramLabels.b.min}f..${domain.paramLabels.b.max}f)

        Text("${domain.paramLabels.c.label}: \${paramC.toInt()} ${domain.paramLabels.c.unit}")
        Slider(value = paramC, onValueChange = { paramC = it }, valueRange = ${domain.paramLabels.c.min}f..${domain.paramLabels.c.max}f)

        Text("${domain.paramLabels.d.label}: \${paramD.toInt()} ${domain.paramLabels.d.unit}")
        Slider(value = paramD, onValueChange = { paramD = it }, valueRange = ${domain.paramLabels.d.min}f..${domain.paramLabels.d.max}f)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScenarioType.entries.forEach { option ->
                FilterChip(
                    selected = scenario == option,
                    onClick = { scenario = option },
                    label = { Text(option.label) }
                )
            }
        }

        Button(
            onClick = {
                val result = BusinessLogicEngine.calculate(
                    itemName = record.name,
                    paramA = paramA.toInt(),
                    paramB = paramB.toInt(),
                    paramC = paramC.toInt(),
                    paramD = paramD.toInt(),
                    scenario = scenario
                )
                onRunSimulation(result)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Generate Sample Results")
        }
    }
}
`;

  const reportsScreenKt = `package ${pkg}

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Screen 4: Reports / Results / Recommendations
 * Explicitly marks all generated outputs as "Sample Results".
 */
@Composable
fun ReportsScreen(
    results: List<SampleSimulationResult>,
    onRunAnother: () -> Unit
) {
    val latest = results.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Reports & Recommendations", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Sample Results · Local Synthetic Prototype Output",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (latest != null) {
            item {
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(latest.sampleNotice, style = MaterialTheme.typography.labelSmall)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(latest.headlineLabel, style = MaterialTheme.typography.bodySmall)
                        Text(latest.headlineValue, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("\${latest.itemName} · \${latest.scenarioLabel}", style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(latest.secondarySummary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            items(latest.recommendations) { rec ->
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(rec, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            Button(onClick = onRunAnother, modifier = Modifier.fillMaxWidth()) {
                Text("Run Another Scenario")
            }
        }
    }
}
`;

  const mainActivityJava = `package ${pkg};

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Java Alternative Entry Point for ${appName} (${domain.domainTitle})
 * Displays Screen 1 entry and delegates to local deterministic Sample Results logic.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView titleView = new TextView(this);
        titleView.setText("${appName} — ${domain.tagline}\\n(Sample Results Prototype)");
        titleView.setPadding(48, 96, 48, 24);
        setContentView(titleView);
    }

    public static String computeSampleSummary(int paramA, int paramB, int paramC) {
        int projectedOutput = Math.max(1, (paramA + paramB * paramC));
        return "Sample Results: Calculated Benchmark = " + projectedOutput;
    }
}
`;

  const settingsGradleKts = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${cleanClassName}"
include(":app")
`;

  const rootBuildGradleKts = `plugins {
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`;

  const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`;

  const gradleWrapperProperties = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

  const appBuildGradleKts = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${pkg}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${pkg}"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-prototype"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
}
`;

  const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.${cleanClassName}">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`;

  const stringsXml = `<resources>
    <string name="app_name">${appName}</string>
</resources>
`;

  const themesXml = `<resources>
    <style name="Theme.${cleanClassName}" parent="android:Theme.Material.Light.NoActionBar" />
</resources>
`;

  const readmeMd = `# ${appName} — Android Studio Project (${domain.domainTitle})

## How to Build & Install the Android APK on Your Phone
1. Unzip this folder and open it directly in **Android Studio** (\`File > Open\`).
2. Wait for Gradle Sync to finish.
3. Connect your Android phone via USB (with USB Debugging enabled) and click **Run 'app'**, OR build an APK file:
   - Click **Build > Build Bundle(s) / APK(s) > Build APK(s)** in Android Studio.
   - Locate \`app/build/outputs/apk/debug/app-debug.apk\`, transfer it to your Android phone, and tap it to install.

## Notes
- Contains 4 connected Material 3 screens: Welcome, Dashboard, Core Business Simulation, and Reports.
- All outputs are explicitly labeled **Sample Results** using synthetic local data (no live AI backend).
`;

  return [
    {
      id: 'main-activity',
      fileName: 'MainActivity.kt',
      zipPath: `app/src/main/java/${pkgPath}/MainActivity.kt`,
      language: 'kotlin',
      description: '4-screen NavHost & Material 3 Bottom Navigation controller',
      content: mainActivityKt,
    },
    {
      id: 'business-models',
      fileName: 'BusinessModels.kt',
      zipPath: `app/src/main/java/${pkgPath}/BusinessModels.kt`,
      language: 'kotlin',
      description: 'Synthetic sample data & deterministic business logic engine',
      content: businessModelsKt,
    },
    {
      id: 'welcome-screen',
      fileName: 'WelcomeScreen.kt',
      zipPath: `app/src/main/java/${pkgPath}/WelcomeScreen.kt`,
      language: 'kotlin',
      description: 'Screen 1: Welcome / Basic Prototype Entry (no auth backend)',
      content: welcomeScreenKt,
    },
    {
      id: 'dashboard-screen',
      fileName: 'DashboardScreen.kt',
      zipPath: `app/src/main/java/${pkgPath}/DashboardScreen.kt`,
      language: 'kotlin',
      description: 'Screen 2: Business Dashboard with metrics & item selector',
      content: dashboardScreenKt,
    },
    {
      id: 'simulation-screen',
      fileName: 'SimulationScreen.kt',
      zipPath: `app/src/main/java/${pkgPath}/SimulationScreen.kt`,
      language: 'kotlin',
      description: 'Screen 3: Interactive Business Function & Scenario Simulator',
      content: simulationScreenKt,
    },
    {
      id: 'reports-screen',
      fileName: 'ReportsScreen.kt',
      zipPath: `app/src/main/java/${pkgPath}/ReportsScreen.kt`,
      language: 'kotlin',
      description: 'Screen 4: Reports / Recommendations marked Sample Results',
      content: reportsScreenKt,
    },
    {
      id: 'manifest',
      fileName: 'AndroidManifest.xml',
      zipPath: `app/src/main/AndroidManifest.xml`,
      language: 'xml',
      description: 'Android app launcher manifest',
      content: androidManifestXml,
    },
    {
      id: 'strings',
      fileName: 'strings.xml',
      zipPath: `app/src/main/res/values/strings.xml`,
      language: 'xml',
      description: 'App name string resource',
      content: stringsXml,
    },
    {
      id: 'themes',
      fileName: 'themes.xml',
      zipPath: `app/src/main/res/values/themes.xml`,
      language: 'xml',
      description: 'Material Light NoActionBar theme',
      content: themesXml,
    },
    {
      id: 'app-gradle',
      fileName: 'app/build.gradle.kts',
      zipPath: `app/build.gradle.kts`,
      language: 'gradle',
      description: 'Module Gradle build config (Material 3 & Compose)',
      content: appBuildGradleKts,
    },
    {
      id: 'root-gradle',
      fileName: 'build.gradle.kts',
      zipPath: `build.gradle.kts`,
      language: 'gradle',
      description: 'Root Android Gradle plugins config',
      content: rootBuildGradleKts,
    },
    {
      id: 'settings-gradle',
      fileName: 'settings.gradle.kts',
      zipPath: `settings.gradle.kts`,
      language: 'gradle',
      description: 'Gradle project repositories & module include',
      content: settingsGradleKts,
    },
    {
      id: 'gradle-props',
      fileName: 'gradle.properties',
      zipPath: `gradle.properties`,
      language: 'text',
      description: 'AndroidX & JVM memory settings',
      content: gradleProperties,
    },
    {
      id: 'gradle-wrapper',
      fileName: 'gradle-wrapper.properties',
      zipPath: `gradle/wrapper/gradle-wrapper.properties`,
      language: 'text',
      description: 'Gradle 8.7 distribution reference',
      content: gradleWrapperProperties,
    },
    {
      id: 'java-alt',
      fileName: 'MainActivity.java',
      zipPath: `java-alternative/MainActivity.java`,
      language: 'java',
      description: 'Optional Java AppCompat alternative entry file',
      content: mainActivityJava,
    },
    {
      id: 'readme',
      fileName: 'README.md',
      zipPath: `README.md`,
      language: 'text',
      description: 'Quick-start instructions to build app-debug.apk',
      content: readmeMd,
    },
  ];
}
