export type BusinessDomainId = 'retail' | 'marketing' | 'hr';

export type ScreenId = 'welcome' | 'dashboard' | 'function' | 'reports';

export interface DashboardMetric {
  id: string;
  label: string;
  value: string;
  delta: string;
  tone: 'positive' | 'warning' | 'neutral';
}

export interface SampleRecord {
  id: string;
  code: string;
  name: string;
  category: string;
  primaryStatLabel: string;
  primaryStatValue: string;
  statusText: string;
  statusTone: 'critical' | 'watch' | 'healthy';
  // Preset simulation parameters
  paramA: number;
  paramB: number;
  paramC: number;
  paramD: number;
}

export interface SimulationInputs {
  selectedRecordId: string;
  itemName: string;
  paramA: number;
  paramB: number;
  paramC: number;
  paramD: number;
  scenario: 'baseline' | 'moderate' | 'peak';
}

export interface SimulationResult {
  id: string;
  timestamp: string;
  domainId: BusinessDomainId;
  itemName: string;
  scenarioLabel: string;
  headlineLabel: string;
  headlineValue: string;
  secondaryMetrics: { label: string; value: string }[];
  riskLabel: string;
  riskTone: 'critical' | 'watch' | 'healthy';
  recommendations: { title: string; detail: string; impact: string }[];
  sampleDisclaimer: string;
}

export interface DomainConfig {
  id: BusinessDomainId;
  domainTitle: string;
  defaultAppName: string;
  tagline: string;
  problemStatement: string;
  samplePersonaName: string;
  samplePersonaRole: string;
  dashboardSubtitle: string;
  listSectionTitle: string;
  functionTitle: string;
  functionSubtitle: string;
  paramLabels: {
    a: { label: string; unit: string; min: number; max: number; step: number };
    b: { label: string; unit: string; min: number; max: number; step: number };
    c: { label: string; unit: string; min: number; max: number; step: number };
    d: { label: string; unit: string; min: number; max: number; step: number };
  };
  scenarioOptions: { id: 'baseline' | 'moderate' | 'peak'; label: string; multiplierText: string }[];
  metrics: DashboardMetric[];
  trendTitle: string;
  trendPoints: { label: string; value: number }[];
  records: SampleRecord[];
}

export const BUSINESS_DOMAINS: Record<BusinessDomainId, DomainConfig> = {
  retail: {
    id: 'retail',
    domainTitle: 'Retail & Inventory',
    defaultAppName: 'StockPulse',
    tagline: 'SKU Demand & Reorder Optimization Prototype',
    problemStatement:
      'Preventing stockouts on high-velocity SKUs while minimizing excess warehouse carrying costs through deterministic reorder point modeling.',
    samplePersonaName: 'Alex Rivera',
    samplePersonaRole: 'Inventory Operations Lead',
    dashboardSubtitle: 'Warehouse B2 · Synthetic Q4 Inventory Snapshot',
    listSectionTitle: 'Monitored SKUs (Sample Data)',
    functionTitle: 'Reorder & EOQ Simulator',
    functionSubtitle: 'Adjust stock, demand velocity, and lead time to compute local reorder triggers.',
    paramLabels: {
      a: { label: 'Current Stock On Hand', unit: 'units', min: 10, max: 600, step: 5 },
      b: { label: 'Avg Daily Unit Demand', unit: 'units/day', min: 2, max: 60, step: 1 },
      c: { label: 'Supplier Lead Time', unit: 'days', min: 2, max: 30, step: 1 },
      d: { label: 'Unit Wholesale Cost', unit: '$', min: 5, max: 180, step: 5 },
    },
    scenarioOptions: [
      { id: 'baseline', label: 'Baseline', multiplierText: '1.0x demand' },
      { id: 'moderate', label: 'Seasonal', multiplierText: '+25% demand' },
      { id: 'peak', label: 'Promo Surge', multiplierText: '+45% demand' },
    ],
    metrics: [
      { id: 'fill-rate', label: 'Order Fill Rate', value: '94.2%', delta: '+1.8% vs Q3', tone: 'positive' },
      { id: 'stock-alerts', label: 'Reorder Alerts', value: '3 SKUs', delta: '2 critical', tone: 'warning' },
      { id: 'turnover', label: 'Stock Turnover', value: '6.4x', delta: 'Annualized', tone: 'neutral' },
      { id: 'carrying', label: 'Est. Holding Savings', value: '$14,280', delta: 'Sample target', tone: 'positive' },
    ],
    trendTitle: '6-Week Synthetic Demand Index',
    trendPoints: [
      { label: 'W1', value: 62 },
      { label: 'W2', value: 68 },
      { label: 'W3', value: 65 },
      { label: 'W4', value: 78 },
      { label: 'W5', value: 84 },
      { label: 'W6', value: 91 },
    ],
    records: [
      {
        id: 'sku-104',
        code: 'SKU-104',
        name: 'Wireless Ergonomic Mouse',
        category: 'Peripherals',
        primaryStatLabel: 'On Hand',
        primaryStatValue: '85 units',
        statusText: 'Critical Reorder',
        statusTone: 'critical',
        paramA: 85,
        paramB: 14,
        paramC: 9,
        paramD: 25,
      },
      {
        id: 'sku-218',
        code: 'SKU-218',
        name: 'USB-C Multiport Dock',
        category: 'Connectivity',
        primaryStatLabel: 'On Hand',
        primaryStatValue: '140 units',
        statusText: 'Monitor',
        statusTone: 'watch',
        paramA: 140,
        paramB: 11,
        paramC: 10,
        paramD: 40,
      },
      {
        id: 'sku-309',
        code: 'SKU-309',
        name: 'Aluminum Laptop Riser',
        category: 'Workstation',
        primaryStatLabel: 'On Hand',
        primaryStatValue: '310 units',
        statusText: 'Healthy',
        statusTone: 'healthy',
        paramA: 310,
        paramB: 8,
        paramC: 7,
        paramD: 30,
      },
      {
        id: 'sku-412',
        code: 'SKU-412',
        name: 'Thermal Shipping Labels',
        category: 'Packaging',
        primaryStatLabel: 'On Hand',
        primaryStatValue: '95 rolls',
        statusText: 'Critical Reorder',
        statusTone: 'critical',
        paramA: 95,
        paramB: 18,
        paramC: 6,
        paramD: 15,
      },
    ],
  },

  marketing: {
    id: 'marketing',
    domainTitle: 'Marketing & Sales',
    defaultAppName: 'CampaignMix',
    tagline: 'Lead Conversion & Channel ROI Optimizer',
    problemStatement:
      'Allocating digital acquisition budget across channels to lower Customer Acquisition Cost (CAC) and maximize qualified sales pipeline.',
    samplePersonaName: 'Alex Rivera',
    samplePersonaRole: 'Growth Marketing Manager',
    dashboardSubtitle: 'Q4 Acquisition Funnel · Synthetic Campaign Dataset',
    listSectionTitle: 'Active Sample Channels',
    functionTitle: 'Channel ROI & Pipeline Simulator',
    functionSubtitle: 'Model ad spend, conversion rate, and deal size to forecast sample pipeline ROI.',
    paramLabels: {
      a: { label: 'Monthly Channel Budget', unit: '$', min: 1000, max: 25000, step: 500 },
      b: { label: 'Estimated Cost Per Lead', unit: '$', min: 15, max: 140, step: 5 },
      c: { label: 'Lead-to-Close Rate', unit: '%', min: 4, max: 35, step: 1 },
      d: { label: 'Avg Closed Deal Value', unit: '$', min: 250, max: 4500, step: 100 },
    },
    scenarioOptions: [
      { id: 'baseline', label: 'Current', multiplierText: '1.0x funnel' },
      { id: 'moderate', label: 'A/B Lift', multiplierText: '+18% conv.' },
      { id: 'peak', label: 'Retargeting', multiplierText: '+32% conv.' },
    ],
    metrics: [
      { id: 'roas', label: 'Blended ROAS', value: '3.8x', delta: '+0.4x vs target', tone: 'positive' },
      { id: 'sql', label: 'Qualified Leads', value: '142', delta: 'Sample Q4', tone: 'neutral' },
      { id: 'cac', label: 'Avg Acquisition Cost', value: '$48.50', delta: '-6% improvement', tone: 'positive' },
      { id: 'pipeline', label: 'Sample Pipeline', value: '$84,200', delta: '4 active channels', tone: 'neutral' },
    ],
    trendTitle: '6-Week Synthetic Lead Velocity',
    trendPoints: [
      { label: 'W1', value: 48 },
      { label: 'W2', value: 54 },
      { label: 'W3', value: 61 },
      { label: 'W4', value: 59 },
      { label: 'W5', value: 74 },
      { label: 'W6', value: 82 },
    ],
    records: [
      {
        id: 'ch-search',
        code: 'CH-01',
        name: 'High-Intent Search Ads',
        category: 'Paid Search',
        primaryStatLabel: 'Sample ROAS',
        primaryStatValue: '4.4x',
        statusText: 'Top Performer',
        statusTone: 'healthy',
        paramA: 8500,
        paramB: 55,
        paramC: 16,
        paramD: 1500,
      },
      {
        id: 'ch-social',
        code: 'CH-02',
        name: 'B2B Social Sponsored Feed',
        category: 'Paid Social',
        primaryStatLabel: 'Sample ROAS',
        primaryStatValue: '2.1x',
        statusText: 'High CAC Watch',
        statusTone: 'watch',
        paramA: 6500,
        paramB: 85,
        paramC: 9,
        paramD: 1350,
      },
      {
        id: 'ch-email',
        code: 'CH-03',
        name: 'Lifecycle Email Nurture',
        category: 'CRM Retention',
        primaryStatLabel: 'Sample ROAS',
        primaryStatValue: '5.6x',
        statusText: 'Top Performer',
        statusTone: 'healthy',
        paramA: 3000,
        paramB: 25,
        paramC: 22,
        paramD: 1150,
      },
      {
        id: 'ch-webinar',
        code: 'CH-04',
        name: 'Executive Product Webinar',
        category: 'Events',
        primaryStatLabel: 'Sample ROAS',
        primaryStatValue: '1.7x',
        statusText: 'Needs Optimization',
        statusTone: 'critical',
        paramA: 5500,
        paramB: 95,
        paramC: 7,
        paramD: 1450,
      },
    ],
  },

  hr: {
    id: 'hr',
    domainTitle: 'HR Management',
    defaultAppName: 'TalentRetain',
    tagline: 'Workforce Attrition Risk & Retention Planner',
    problemStatement:
      'Identifying anonymized department workload and compensation gaps early to reduce voluntary turnover costs without storing sensitive personal PII.',
    samplePersonaName: 'Alex Rivera',
    samplePersonaRole: 'People Analytics Partner',
    dashboardSubtitle: 'Anonymized Cohort Summary · Zero PII Sample Data',
    listSectionTitle: 'Department Cohorts (Synthetic)',
    functionTitle: 'Attrition & Retention Simulator',
    functionSubtitle: 'Model engagement, weekly overtime, and pay competitiveness on anonymized cohorts.',
    paramLabels: {
      a: { label: 'Cohort Headcount', unit: 'staff', min: 10, max: 120, step: 5 },
      b: { label: 'Avg Engagement Score', unit: '/ 10', min: 3, max: 10, step: 1 },
      c: { label: 'Avg Weekly Overtime', unit: 'hrs/wk', min: 0, max: 20, step: 1 },
      d: { label: 'Comp vs Market Index', unit: '%', min: 80, max: 115, step: 5 },
    },
    scenarioOptions: [
      { id: 'baseline', label: 'As-Is', multiplierText: 'No change' },
      { id: 'moderate', label: 'Flex Policy', multiplierText: '-3 hrs OT' },
      { id: 'peak', label: 'Retention Plan', multiplierText: '+5% Comp & Flex' },
    ],
    metrics: [
      { id: 'retention', label: 'Annual Retention', value: '91.4%', delta: '+2.1% target', tone: 'positive' },
      { id: 'cohorts', label: 'At-Risk Cohorts', value: '2 Teams', delta: 'Overtime driver', tone: 'warning' },
      { id: 'tenure', label: 'Avg Cohort Tenure', value: '3.2 yrs', delta: 'Synthetic avg', tone: 'neutral' },
      { id: 'exposure', label: 'Turnover Exposure', value: '$62,000', delta: 'Est. replacement', tone: 'warning' },
    ],
    trendTitle: '6-Month Cohort Engagement Index',
    trendPoints: [
      { label: 'Jun', value: 79 },
      { label: 'Jul', value: 76 },
      { label: 'Aug', value: 74 },
      { label: 'Sep', value: 71 },
      { label: 'Oct', value: 73 },
      { label: 'Nov', value: 78 },
    ],
    records: [
      {
        id: 'coh-eng',
        code: 'COH-ENG',
        name: 'Platform Engineering Cohort',
        category: 'Technology',
        primaryStatLabel: 'Risk Index',
        primaryStatValue: '34% High',
        statusText: 'Action Required',
        statusTone: 'critical',
        paramA: 45,
        paramB: 6,
        paramC: 11,
        paramD: 90,
      },
      {
        id: 'coh-ops',
        code: 'COH-OPS',
        name: 'Fulfillment Operations Cohort',
        category: 'Operations',
        primaryStatLabel: 'Risk Index',
        primaryStatValue: '24% Med',
        statusText: 'Monitor',
        statusTone: 'watch',
        paramA: 60,
        paramB: 7,
        paramC: 8,
        paramD: 95,
      },
      {
        id: 'coh-fin',
        code: 'COH-FIN',
        name: 'Corporate Finance Cohort',
        category: 'Finance',
        primaryStatLabel: 'Risk Index',
        primaryStatValue: '11% Low',
        statusText: 'Healthy',
        statusTone: 'healthy',
        paramA: 25,
        paramB: 8,
        paramC: 3,
        paramD: 105,
      },
      {
        id: 'coh-cs',
        code: 'COH-CS',
        name: 'Customer Success Cohort',
        category: 'Support',
        primaryStatLabel: 'Risk Index',
        primaryStatValue: '29% High',
        statusText: 'Action Required',
        statusTone: 'critical',
        paramA: 35,
        paramB: 6,
        paramC: 9,
        paramD: 90,
      },
    ],
  },
};

export function runLocalSimulation(
  domainId: BusinessDomainId,
  inputs: SimulationInputs
): SimulationResult {
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const id = `sim-${Date.now()}`;

  if (domainId === 'retail') {
    const multiplier = inputs.scenario === 'peak' ? 1.45 : inputs.scenario === 'moderate' ? 1.25 : 1.0;
    const scenarioLabel =
      inputs.scenario === 'peak'
        ? 'Promo Surge (+45%)'
        : inputs.scenario === 'moderate'
        ? 'Seasonal (+25%)'
        : 'Baseline (1.0x)';

    const adjustedDailyDemand = Math.round(inputs.paramB * multiplier * 10) / 10;
    const safetyStock = Math.ceil(adjustedDailyDemand * 4);
    const reorderPoint = Math.ceil(adjustedDailyDemand * inputs.paramC + safetyStock);
    const daysOfSupply = Math.max(0, Math.round((inputs.paramA / Math.max(1, adjustedDailyDemand)) * 10) / 10);
    const eoqQty = Math.max(25, Math.ceil(adjustedDailyDemand * 21));
    const orderCost = eoqQty * inputs.paramD;

    const needsImmediate = inputs.paramA <= reorderPoint;
    const closeToRop = inputs.paramA <= reorderPoint * 1.25;

    return {
      id,
      timestamp,
      domainId,
      itemName: inputs.itemName,
      scenarioLabel,
      headlineLabel: 'Calculated Reorder Point (ROP)',
      headlineValue: `${reorderPoint} units`,
      secondaryMetrics: [
        { label: 'Days Until Stockout', value: `${daysOfSupply} days` },
        { label: 'Recommended Order Qty', value: `${eoqQty} units` },
        { label: 'Est. Purchase Order Cost', value: `$${orderCost.toLocaleString()}` },
        { label: 'Safety Buffer Included', value: `${safetyStock} units` },
      ],
      riskLabel: needsImmediate ? 'Critical Reorder Needed' : closeToRop ? 'Watchlist · Order Soon' : 'Healthy Coverage',
      riskTone: needsImmediate ? 'critical' : closeToRop ? 'watch' : 'healthy',
      recommendations: [
        {
          title: needsImmediate
            ? `Issue Purchase Order for ${eoqQty} units immediately`
            : `Schedule next replenishment review in ${Math.max(1, Math.floor(daysOfSupply - inputs.paramC))} days`,
          detail: `Current on-hand (${inputs.paramA} units) vs. ${inputs.paramC}-day supplier lead time at ${adjustedDailyDemand} units/day.`,
          impact: needsImmediate ? 'Avoids projected stockout' : 'Maintains 95%+ fill rate',
        },
        {
          title: 'Maintain 4-day dynamic safety stock buffer',
          detail: `Allocating ${safetyStock} buffer units absorbs short-term variance under ${scenarioLabel}.`,
          impact: 'Protects service level',
        },
        {
          title: 'Consolidate supplier freight batch',
          detail: `Batching ${eoqQty} units ($${orderCost.toLocaleString()}) reduces per-unit receiving overhead.`,
          impact: 'Lower carrying cost',
        },
      ],
      sampleDisclaimer: 'Sample Results · Calculated locally using synthetic SKU assumptions (no live ERP/AI backend).',
    };
  }

  if (domainId === 'marketing') {
    const convBoost = inputs.scenario === 'peak' ? 1.32 : inputs.scenario === 'moderate' ? 1.18 : 1.0;
    const scenarioLabel =
      inputs.scenario === 'peak'
        ? 'Retargeting (+32% conv.)'
        : inputs.scenario === 'moderate'
        ? 'A/B Lift (+18% conv.)'
        : 'Current Funnel (1.0x)';

    const budget = inputs.paramA;
    const cpl = inputs.paramB;
    const effectiveConvRate = Math.min(45, Math.round(inputs.paramC * convBoost * 10) / 10);
    const leads = Math.max(1, Math.floor(budget / cpl));
    const closedDeals = Math.max(1, Math.round((leads * effectiveConvRate) / 100));
    const projectedRevenue = closedDeals * inputs.paramD;
    const roas = Math.round((projectedRevenue / Math.max(1, budget)) * 10) / 10;
    const netProfit = projectedRevenue - budget;

    return {
      id,
      timestamp,
      domainId,
      itemName: inputs.itemName,
      scenarioLabel,
      headlineLabel: 'Projected Channel ROAS',
      headlineValue: `${roas}x`,
      secondaryMetrics: [
        { label: 'Projected Leads', value: `${leads} MQLs` },
        { label: 'Est. Closed Deals', value: `${closedDeals} deals` },
        { label: 'Sample Revenue', value: `$${projectedRevenue.toLocaleString()}` },
        { label: 'Net Contribution', value: `${netProfit >= 0 ? '+' : '-'}$${Math.abs(netProfit).toLocaleString()}` },
      ],
      riskLabel: roas >= 3.0 ? 'Scale Budget Candidate' : roas >= 2.0 ? 'Moderate Efficiency' : 'Underperforming CAC',
      riskTone: roas >= 3.0 ? 'healthy' : roas >= 2.0 ? 'watch' : 'critical',
      recommendations: [
        {
          title: roas >= 3.0 ? 'Reallocate +15% spend into this channel' : 'Tighten audience targeting to lower CPL',
          detail: `At $${cpl} CPL and ${effectiveConvRate}% close rate, expected return is $${projectedRevenue.toLocaleString()} on $${budget.toLocaleString()} spend.`,
          impact: roas >= 3.0 ? 'Expands high-ROI pipeline' : 'Reduces wasted ad spend',
        },
        {
          title: 'Prioritize rapid 15-minute lead follow-up',
          detail: `Improving close rate from ${inputs.paramC}% toward ${Math.min(40, inputs.paramC + 3)}% adds ~${Math.max(1, Math.round((leads * 3) / 100))} extra deals.`,
          impact: `+$${(Math.max(1, Math.round((leads * 3) / 100)) * inputs.paramD).toLocaleString()} sample lift`,
        },
        {
          title: 'Cap frequency and audit landing page friction',
          detail: 'Review funnel drop-off weekly using anonymized aggregate cohort metrics.',
          impact: 'Stabilizes CAC',
        },
      ],
      sampleDisclaimer: 'Sample Results · Deterministic funnel simulation on synthetic campaign metrics (no live ad API).',
    };
  }

  // HR Management
  const otReduction = inputs.scenario === 'peak' ? 4 : inputs.scenario === 'moderate' ? 3 : 0;
  const compBoost = inputs.scenario === 'peak' ? 5 : 0;
  const scenarioLabel =
    inputs.scenario === 'peak'
      ? 'Retention Plan (+5% Comp & Flex)'
      : inputs.scenario === 'moderate'
      ? 'Flex Policy (-3 hrs OT)'
      : 'As-Is Baseline';

  const effectiveOt = Math.max(0, inputs.paramC - otReduction);
  const effectiveComp = inputs.paramD + compBoost;
  const engagementGap = Math.max(0, 9 - inputs.paramB) * 3.8;
  const overtimePenalty = effectiveOt * 1.9;
  const compPenalty = Math.max(0, 100 - effectiveComp) * 1.1;
  const rawRisk = Math.min(68, Math.max(6, Math.round(8 + engagementGap + overtimePenalty + compPenalty)));
  const estDepartures = Math.max(1, Math.round((inputs.paramA * rawRisk) / 100));
  const avgReplacementCost = 14500;
  const turnoverCost = estDepartures * avgReplacementCost;

  return {
    id,
    timestamp,
    domainId,
    itemName: inputs.itemName,
    scenarioLabel,
    headlineLabel: 'Projected Annual Attrition Risk',
    headlineValue: `${rawRisk}%`,
    secondaryMetrics: [
      { label: 'Est. Annual Departures', value: `${estDepartures} of ${inputs.paramA}` },
      { label: 'Replacement Exposure', value: `$${turnoverCost.toLocaleString()}` },
      { label: 'Effective Weekly OT', value: `${effectiveOt} hrs/wk` },
      { label: 'Market Comp Index', value: `${effectiveComp}%` },
    ],
    riskLabel: rawRisk >= 28 ? 'High Attrition Risk' : rawRisk >= 18 ? 'Elevated Watchlist' : 'Healthy Retention',
    riskTone: rawRisk >= 28 ? 'critical' : rawRisk >= 18 ? 'watch' : 'healthy',
    recommendations: [
      {
        title: effectiveOt > 6 ? 'Cap recurring overtime via sprint rebalancing' : 'Maintain sustainable workload cadence',
        detail: `Reducing overtime from ${inputs.paramC} hrs/wk to ${effectiveOt} hrs/wk relieves burnout pressure across the ${inputs.paramA}-person cohort.`,
        impact: 'Primary risk reducer',
      },
      {
        title: effectiveComp < 98 ? 'Target compensation band calibration' : 'Highlight total rewards & career mobility',
        detail: `Cohort sits at ${effectiveComp}% of market benchmark; targeted adjustments cost less than $${turnoverCost.toLocaleString()} turnover exposure.`,
        impact: 'Protects institutional knowledge',
      },
      {
        title: 'Deploy structured manager check-ins (aggregate only)',
        detail: 'Track cohort engagement pulse monthly without storing individual personal identifiers.',
        impact: 'Early warning visibility',
      },
    ],
    sampleDisclaimer: 'Sample Results · Anonymized cohort simulation only (no sensitive personal or employee PII).',
  };
}
